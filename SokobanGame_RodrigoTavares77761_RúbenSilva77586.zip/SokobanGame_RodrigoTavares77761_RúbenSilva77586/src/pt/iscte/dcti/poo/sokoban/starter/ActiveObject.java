package pt.iscte.dcti.poo.sokoban.starter;

import pt.iul.ista.poo.utils.Direction;

public interface ActiveObject{
	
	void move(Direction nextDirection);
	
}
